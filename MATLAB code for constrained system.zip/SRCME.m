function SRCME(fnum,dimnum,xnum,xlrange,tol,maxit,maxfev)
% Signal recovery with constrained monotone nonlinear equations
% Peiting Gao et al.
% Journal of applied analysis and computation 
% Volume 13, Number 4, August 2023, 2006�2025
% DOI:10.11948/20220335
% Global convergence method
% call: dlcs(f,x0,tol,maxit)
% Input:  dimnum= dimension
%         fnum= function number
%        xnum= initial iterate number
%        tol= stoping tolarance
%        maxit= maximum nuber of iteration
tic;
%%%%% default maxit, fev and tol, constant input %%%%%%%%%%%%%%%%%%%%%%%
if nargin<7
    maxfev=2000;
end
if nargin<6
    maxit=1000; % default max. iter
end
if nargin<5
    tol=10^(-10); % default tolarance
end
%%%%%%%%%%%%% variable input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin<4
    xlrange=[]; % excel range
end
if nargin<3
    xnum=1; % default initial point
end
if nargin<2
    dimnum=1; % default problem
end
if nargin<1
    fnum=1; % default dimension
end
%%%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch dimnum
    case 1
        dim=5000;
    case 2
        dim=10000;
    case 3
        dim=50000;
    case 4
        dim=50000;
    case 5
        dim=100000;
%     case 6
%         dim=10000;
%     case 7
%         dim=20000;
%     case 8
%         dim=50000;
%     case 9
%         dim=70000;
%     case 10
%         dim=100000;
    otherwise
        dim=dimnum;    % for any other dimension    
end
%%%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=fnum;
switch problem
        case 1
      l=0; u=+inf;
        f='cp0';
        proj='Pj';
       case 2
      l=0; u=+inf;
        f='cp5';
        proj='Pj';  
       case 3
      l=0; u=+inf;
        f='cp3';
        proj='Pj'; 
       case 4
       l=0; u=+inf;
        f='k16';
        proj='Pj';  
      case 5
      l=0; u=+inf;
        f='k26';
        proj='Pj';   
      case 6
      l=0; u=+inf;
        f='k31';
        proj='Pj';
      case 7
      l=0; u=+inf;
        f='kab5';
        proj='Pj'; 
      case 8
      l=0; u=+inf;
        f='k13';
        proj='Pj';   
    otherwise
        f='fnum'; %for any other problem
end 
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%
guess=xnum;
switch guess
    case 1
        x0=(((1:dim)')/dim);
        %x0=dim-((dim-(1:dim))/dim)';
        %x0=((1:dim)/dim)';
        %x0=(-1*((-1).^(1:dim)-3)')/2;
        %x0=1*ones(dim,1)/2;
        %x0=1-(((1:dim)')/dim);
    case 2
        x0=1-(((1:dim)')/dim);
        %x0=(1./(1:dim))';
        %x0=(-1*((-1).^(1:dim)-2)')/2;
        %x0=1-(((1:dim)')/dim);
        %x0=1*ones(dim,1);
    case 3
        x0=2-(((1:dim)')/dim);
        %x0=(1./(3.^(1:dim))'); 
        %x0=(-2*((-1).^(1:dim)-2)')/2;
       %x0=(-2*((-1).^(1:dim)-2)')/2;
        %x0=(-1*((-1).^(1:dim)-5)')/2;
        %x0=((dim-(1:dim))/dim)';
        %x0=1*ones(dim,1)/3;
    case 4 
        x0=((dim-(1:dim))/dim)';
        %x0=0.5*ones(dim,1);
        %x0=(-1*((-1).^(1:dim)-4)')/2;
        %x0=((dim-(1:dim))/dim)';
    case 5
        %x0=(-2*((-1).^(1:dim)-2)')/2;
        x0=(-1*((-1).^(1:dim)-2)')/4;
       %x0=(-2*((-1).^(1:dim)-2)')/2;
        %x0=1-(((1:dim)')/dim);
        %x0=(-1*((-1).^(1:dim)-5)')/3;
    case 6
        x0=(-2*((-1).^(1:dim)-2)')/2;
        %x0=1-(((1:dim)')/dim);
        %x0=(-1*((-1).^(1:dim)-6)')/2;
         %x0=(-1*((-1).^(1:dim)-3)')/2;
    case 7
         x0=0.5*ones(dim,1);
        %x0=1-(((1:dim)')/dim);
    case 8
          x0=(-1*((-1).^(1:dim)-6)')/2;
        %x0=1-(((1:dim)')/dim);
        %x0=((dim-(1:dim))/dim)';   
    otherwise
    x0=xnum; %for any other initial point
end
%Step 0 Initialization

ITER=0; %iteration
FEV=0; % function evaluation
bck=0; % backtracking counter
% line search parameters
%bita=1; 

% gamma is for initial stepsize beta
%gam=1e-8; 
% Step 1 stopping rule
F0=feval(f,x0); % evaluating F(x0);
FEV=FEV+1;
norm_F0=sqrt(sum(F0.^2)); % norm of F(x0)
d0=-F0; % initial direction
%%%%%% Step 2 main loop%%%%%%%%%%%%%%%%%%%%%%%%%
while(ITER<=maxit && norm_F0>tol)
    ro=0.4; m=0; sig=0.0001;
% p,q are for nonnegative parameter t
%r=0.5;
F0=feval(f,x0);
%     dd1=F0'*d0; % directional derivative (must be negative always!)
%     %disp ('directional derivative   ', num2str(dd1))
%     bita=dd1/(d0'*(feval(f,x0+gam*d0)-F0)/gam);
%     if bita<=1e-6
%        bita=1;
%     end
    bita=1;
    % Step 3: line search %(-((feval(f,x0+bita*(ro)^m*d0))'*d0) <sig*bita*(ro)^m*(norm(d0))^2 && m<=10)
    while (-((feval(f,x0+bita*(ro)^m*d0))'*d0) <sig*bita*(ro)^m*(norm(d0))^2 && m<=10)           
           %(-((feval(f,x0+bita*(ro)^m*d0))'*d0) <sig*bita*(ro)^m*(norm(((feval(f,x0+bita*(ro)^m*d0)))))*(norm(d0))^2 && m<=10)

        m=m+1;
        FEV=FEV+1;
    end
    if FEV>=maxfev
            disp('maximum number of function evalution reached')
            return;
    end
    % backtracking counter
    if m
        bck=bck+1;
    end
    alph=bita*(ro)^(m); 
    z=x0+alph*d0;
    Fz= feval(f,z); % computing f(z)
    FEV=FEV+1;
    if (feval(proj,(z),l,u)==z & norm(Fz)<tol)
        x0=z;
        F0=Fz;
        norm_F0= norm(F0);
        disp('zk is in the convex set and its the solution at iteration number')
        disp((num2str(ITER)))
        break
    else
   zetak=Fz'*(x0-z)/(Fz'*Fz); % computing zetak
        P=feval(proj,(x0-zetak*Fz),l,u); % projection on convex se
    x=P;
    F1=feval(f,x);
    s=x-x0; % Liu & Li choice of sk for DY-type projection method
    y=F1-F0;
    r=1;
    % modified y using line search
    yb=y+r*s;
    tk1=(s'*yb)/(2*(yb'*yb));
    tk2=(F1'*yb)/(2*(yb'*yb));
    tk3=(F1'*s)/(2*(yb'*yb));
    tk4=(F1'*s)/(2*(s'*yb));
    d1= -tk1*F1-tk2*s+tk3*yb-tk4*s; % spectral Dai-Liao direction
    end
    x0=x;
    F0=F1;
    d0=d1;
    norm_F0=sqrt(sum(F0.^2));
    ITER=ITER+1;
end
x0;
disp([num2str(ITER) ' / ' num2str(FEV)    ' / '  num2str(bck) ' / ' num2str(toc)  ' / ' num2str(norm_F0) ])
 disp((num2str(f)))
disp((num2str(dim)))
table1='DKclust.xlsx';
 T={ITER,FEV,toc,norm_F0};
 sheet=fnum;
 xclRange=xlrange;
 xlswrite(table1,T,sheet,xclRange);
%  table1='dlcs.xlsx';
%  T={num2str(ITER),num2str(FEV),num2str(toc),num2str(norm_F0)};
%  sheet=fnum;
%  xlRange=xlrange;
%  xlswrite(table1,T,sheet,xlRange);
%winopen(table1)
toc;
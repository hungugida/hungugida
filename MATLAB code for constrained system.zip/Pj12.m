function [P]=Pj12(y,l,u)
P=max(l,min(y,u));
function [F] = k31(x)
% Evaluate the tridiagonal exponential function 
% x0=(1.5,1.5,...)
n = length(x);
%F = zeros(n,1);
i=2:(n);
F(1)=3*x(1)+exp(sin(x(1)))-1;
F(i)=3*x(i)+exp(sin(x(i)))-1;
F=F(:);
% Projection P=max(x,0)
function runsexp(solvernum, num_prob,num_dim, inpointnum)
tic
% function that perform the runs for a MSP experiments
% Multivariated Spectral Gradient Projection Method for Convex constraints
% Written by H. Mohammad April 1st 2018
% Note this code is for problems with standard initial points
% input: num_prob ---- number of problems
%        num_dim ----- number of dimensions
%        num_ini ------- number of initial points
%        solvernum----- The user define number of the solver, corresponding
%        to initial cell number in the excel file
% last update 01/11/2018
cons=inpointnum;
for i=1:num_prob
    for j=1:num_dim
        for l=1:inpointnum
            k=cons*(j-1)+l+2; 
            probnum=i;
            dimnum=j;
            inpointnum=l;
            xlrange=xlRange(solvernum,k);
            switch solvernum
                case 3
                    Algorithm1(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                    %NewHZ1(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                    %MDF11(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                    %NHZIS(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                   %NIHZPM(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                case 7
                    ACGD(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                    %NewHZ2(probnum,dimnum,inpointnum,xlrange); % HZDK Auwal and Kumam 2018
                    %JsHZ1(probnum,dimnum,inpointnum,xlrange); % CG_DESCENT Xiao 2013 
                    %NEHZPM(probnum,dimnum,inpointnum,xlrange); % CG_DESCENT Xiao 2013 
                 case 11
                     MDKM(probnum,dimnum,inpointnum,xlrange); %
                    %JsHZ1(probnum,dimnum,inpointnum,xlrange); % SP Xiao 2009 
                 case 15
                     SRCME(probnum,dimnum,inpointnum,xlrange); % Diagonalized H. Mohammad & A. B. Abubakar 2018
                     %EPGMconvex(probnum,dimnum,inpointnum,xlrange); % Diagonalized H. Mohammad & A. B. Abubakar 2018
                 case 19
                     SDYCG(probnum,dimnum,inpointnum,xlrange);  
                 case 23
                    CGDconvex(probnum,dimnum,inpointnum,xlrange);
                otherwise
                    disp('wrong solver number')
                    break
            end
            
        end
    end
    
end
toc

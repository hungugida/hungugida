function [alpha, x, f, grad, fail, nsteps] = zoom1(...
      lo, hi, flo, fhi, glo, ghi, f0, g0, x0, d,op, c1, c2)
fail = 0;
lo2 = hi;  
flo2 = fhi;
glo2 = ghi;
nsteps = 0;
while lo ~= hi & nsteps < 50  
   nsteps = nsteps + 1;
   bisect = (lo + hi)/2;    
   interp = cubic_interp(lo, lo2, flo, flo2, glo, glo2); 
   if inside(interp, lo, bisect)  
      atry = interp; 
   else
      atry = bisect; 
   end;
   xtry = x0 + atry*d;         
   ftry=test_functions(xtry,op);      
   gradtry=test_functions(xtry,op,1);
   gtry = gradtry'*d;          
   if ftry > f0 + c1*atry*g0 | ftry >= flo    
      hi = atry; 
      lo2 = hi; flo2 = ftry; glo2 = gtry;  
   else
      if abs(gtry) <= -c2*g0     
         alpha = atry; x = xtry; f = ftry; grad = gradtry;
         return
      end
      if gtry*(hi - lo) >= 0     
         hi = lo; 
      end
      lo2 = lo; flo2 = flo; glo2 = glo;   
      lo = atry; flo = ftry; glo = gtry;  
   end 
end 
alpha = atry; x = xtry; f = ftry; grad = gradtry; fail = 1; 
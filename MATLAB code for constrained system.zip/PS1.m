function hag5(fnum,dimnum,xnum,xlrange,tol,maxit,maxfev)
% A Dai Liao type projection algorithm for convex constraints monotone equations
% with applications in compressive sensing
% A. B. Abubakar, H. Mohammad and P. Kumam March 30 2018
% Global convergence method
% call: dlcs(f,x0,tol,maxit)
% Input:  dimnum= dimension
%         fnum= function number
%        xnum= initial iterate number
%        tol= stoping tolarance
%        maxit= maximum nuber of iteration
tic;
%%%%% default maxit, fev and tol, constant input %%%%%%%%%%%%%%%%%%%%%%%
if nargin<7
    maxfev=2000;
end
if nargin<6
    maxit=1000; % default max. iter
end
if nargin<5
    tol=10^(-5); % default tolarance
end
%%%%%%%%%%%%% variable input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if nargin<4
    xlrange=[]; % excel range
end
if nargin<3
    xnum=1; % default initial point
end
if nargin<2
    dimnum=1; % default problem
end
if nargin<1
    fnum=1; % default dimension
end
%%%%%%%%%%%%%%%%%%% defining dimension%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
switch dimnum
    case 1
        dim=1000;
    case 2
        dim=5000;
    case 3
        dim=10000;
    case 4
        dim=50000;
    case 5
        dim=100000;
%     case 6
%         dim=10000;
%     case 7
%         dim=20000;
%     case 8
%         dim=50000;
%     case 9
%         dim=70000;
%     case 10
%         dim=100000;
    otherwise
        dim=dimnum;    % for any other dimension    
end
%%%%%%%%%%%%%%%%%% defining problems%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
problem=fnum;
switch problem
    case 1
        f='p10';
%         proj='Proj1';
    case 2
        f='c2';
        proj='Proj1';
    case 3
        f='c3';
        proj='Proj1';
    case 4
        f='c4';
        proj='Proj1';
    case 5
        f='c5';
        proj='Proj1';
    case 6
        f='c6';
        proj='Proj1';
    case 7
        f='c7';
        proj='Proj1';
    case 8
        f='c8';
        proj='Proj1';
    case 9
        f='c9';
        proj='Proj1';
    case 10
        f='c10';
        proj='Proj1';
    case 11
        f='c11';
        proj='Proj1';    
    case 12
         f='c12';
         proj='proj2';
    case 13
        f='c13';
        proj='proj3';
    otherwise
        f='fnum'; %for any other problem
end 
%%%%%%%%%%%%%%%%%% defining initial points%%%%%%%%%%%%%%%%%%%%%%%
guess=xnum;
switch guess
    case 1
        x0=ones(dim,1);
    case 2
        x0=2*ones(dim,1);
    case 3
        %x0=0.1*ones(dim,1);
        x0=3*ones(dim,1);
    case 4
        x0= 5*ones(dim,1);
    case 5
        x0=8*ones(dim,1);
    case 6
        x0=0.5*ones(dim,1);
    case 7
        x0=0.1*ones(dim,1);
    case 8
        %x0=10*ones(dim,1);
        x0=10*ones(dim,1);
%     case 9
%         x0=(1./(1:dim))';
%     case 10
%         x0=10*ones(dim,1);
%     case 11
%         x0=((dim-(1:dim))/dim)';
%     case 12
%         x0=rand(dim,1); % random numbers between 0 and 1
     otherwise
        x0=xnum; %for any other initial point
end
%Step 0 Initialization

ITER=0; %iteration
FEV=0; % function evaluation
bck=0; % backtracking counter
% line search parameters
%bita=1; 

% gamma is for initial stepsize beta
%gam=1e-8; 
% Step 1 stopping rule
F0=feval(f,x0); % evaluating F(x0);
FEV=FEV+1;
norm_F0=sqrt(sum(F0.^2)); % norm of F(x0)
d0=-F0; % initial direction
alph=1; g=1;alph1=1;
%%%%%% Step 2 main loop%%%%%%%%%%%%%%%%%%%%%%%%%
while(ITER<=maxit && norm_F0>tol)
   ro=0.8; m=0; sig=0.0001;
% p,q are for nonnegative parameter t
%p=0.8; q=-0.1;
F0=feval(f,x0);
%     dd1=F0'*d0; % directional derivative (must be negative always!)
%     %disp ('directional derivative   ', num2str(dd1))
%     bita=dd1/(d0'*(feval(f,x0+gam*d0)-F0)/gam);
%     if bita<=1e-6
%        bita=1;
%     end

z=x0-(1/g)*alph*F0;
    bita=1;
    % Step 3: line search
    while (((feval(f,x0+bita*(ro)^m*d0))'*d0) > -sig*bita*(ro)^m*(norm(d0))^2 && m<=10)
        m=m+1;
        FEV=FEV+1;
    end
    if FEV>=maxfev
            disp('maximum number of function evalution reached')
            return;
    end
    % backtracking counter
    if m
        bck=bck+1;
    end
    alph=bita*(ro)^(m); % accepted step size
    % Step 4: Projection
     % computing z
    Fz= feval(f,z); % computing f(z)
    FEV=FEV+1;
    s=z-x0;
    y=Fz-F0;
    if((g*Fz'*y)/(alph*(Fz)'*Fz)>=0);
        g1=(g*Fz'*y)/(alph*(Fz)'*Fz);
    else
        g1=1;
    end
    x=z-alph*(1/g1)*Fz;
%     zetak=Fz'*(x0-z)/(norm(Fz)^2); % computing zetak
%     P=feval(proj,(x0-zetak*Fz)); % projection on x0-zetak*Fz
%     x=P;
    %[P,~]=feval(f,(x0-zetak*Fz)); % old projection formula
    %x=P;
    F1=feval(f,x);
    %norm_F1=sqrt(sum(F1.^2));
    FEV=FEV+1;
    % Step 5: Direction
%     s=x-x0;
    %s=z-x0; % Liu & Li choice of sk for DY-type projection method
%     y=F1-F0;
    % computing the Descent Dai-Liao CG parameter
%     t=1+sqrt(1+(((s'*y)^2)/((norm(s))^2*(norm(y))^2)));
%     bitak=(F1'*y)/(d0'*y)-t*(norm(y))^2*(F1'*d0)/(d0'*y);
%     d0= -F1+bitak*d0; % spectral Dai-Liao direction
%     % updating
    x0=x;
    F0=F1;
    g=g1;
    norm_F0=sqrt(sum(F0.^2));
    ITER=ITER+1;
end
x0;
disp([num2str(ITER) ' / ' num2str(FEV)    ' / '  num2str(bck) ' / ' num2str(toc)  ' / ' num2str(norm_F0) ])
 table1='dlcs2.xlsx';
 T={ITER,FEV,toc,norm_F0};
 sheet=fnum;
 xclRange=xlrange;
 xlswrite(table1,T,sheet,xclRange);
%  table1='dlcs.xlsx';
%  T={num2str(ITER),num2str(FEV),num2str(toc),num2str(norm_F0)};
%  sheet=fnum;
%  xlRange=xlrange;
%  xlswrite(table1,T,sheet,xlRange);
%winopen(table1)
toc;
function r=L_Search(x,d,op)
clear h k t s a
t=0:.2:50;
j=ones(1,1);
for i=0:.2:50
h(j)=test_functions(x+t(j)*d,op);
j=j+1;
end
k=find(h==min(h));
r=t(k);
s=1;
if length(k)>1
    r=choose1(s,r,x,d,op);
end
clear h t k
for i=1:7
    if r-s<0
        a=0;
    else
        a=r-s;
    end
t=a:s/10:r+s;
j=1;
% new loof
for i=a:s/10:r+s
h(j)=test_functions(x+t(j)*d,op);
j=j+1;
end
k=find(h==min(h));
r=t(k);
if length(k)>1
    r=choose1(s,r,x,d,op);
end
 s=s/10;
clear h 
end
function [F] = kab5(x)
% Evaluate the mononote nonlinear problem with convex constraint
% x0=(1,1,...)
% to call the function evaluation and projection type [P,F]=feval(f,x)
% to call function evaluation only type [~,F]=feval(f,x)
% last update 30/03/2018
n = length(x);
i=2:n-1;
F(1)= 3*x(1)+cos(x(1))-1;
F(i)= 3*x(i-1)+3*x(i)+cos(x(i))-1;
F(n)= 3*x(n)+cos(x(n))-1;
F=F(:);
%P=max(x,0);
% function [P,F]=c10(x)
% Evaluate the discretize of nondiffrentiable Dirichlet problem
% n must be perfect square
% n = length(x);
% r=sqrt(n);
% h=1/(r+1);
% F = zeros(n,1);
% i=1:(n);
% B=(gallery('tridiag',r,-1,4,-1));
% A=kron(-eye(r),B);
% F(i)=A*x-h^2*((max(x(i)-1,0.5*x(i)-0.5))+ones(n,1));
% F=F(:);
% P=max(x,0);
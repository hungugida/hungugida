function [F] = cp3(x)
% Evaluate a nonsmooth and monotone function
%
n = length(x);
%F = zeros(n,1);
%h=1/(n+1);
i=1:(n);
F(i)=2*x(i)-sin(abs(x(i)));
F=F(:);
%P=max(x,0);

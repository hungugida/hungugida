function r=choose1(sc,rc,xc,dc,opc)
n=length(rc);
for i=1:n
    c(i)=min(test_functions(xc+(rc(i)-sc/100)*dc,opc),test_functions(xc+(rc(i)+sc/100)*dc,opc));
end
j=find(min(c)==c);
r=rc(j(1));
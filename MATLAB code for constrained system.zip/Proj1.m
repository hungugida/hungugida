%projection operator of MSDY
function [P]=Proj1(x)
P=max(x,0);

  function [F] = k13(x)
% Evaluate the tridiagonal exponential function 
% x0=(1.5,1.5,...)
n = length(x);
%F = zeros(n,1);
i=2:(n-1);
%h=1/(n+1);
%h=1/i;
F(1)=x(1)-exp(cos((x(1)+x(2))/2));
F(i)=x(i)-exp(cos(0.i*(x(i-1)+x(i)+x(i+1))));
F(n)=x(n)-exp(cos((x(n-1)+x(n))/n));
F=F(:);
% Projection P=max(x,0)
%exp(cos((x(i-1)+x(i)+x(i+1))/i));
%exp(cos(0.i*(x(i-1)+x(i)+x(i+1))));
function [P]=Pj2(x,~,~)
% project an n-dim vector x to the convex set Cn
% Cn = { x : x n-dim, x > -1, sum(x) <= n}
% Coded by
% Hassan Mohammad hmuhd.mth@buk.edu.ng
% October, 2018
m = length(x); bget = false;
s = sort(x,'descend');
tmpsum = 0;
for ii = 1:m-1
    tmpsum = tmpsum + s(ii);
    tmax = (tmpsum -(m))/ii;
    if tmax >= s(ii+1)
        bget = true;
        break;
    end
end
tmpsum=tmpsum+s(m);    
if ~bget
    tmax = (tmpsum-m)/m;
end
if (tmpsum<=m && min(x)>-1)
    P=x;
else
    P = max(x-tmax,0);
end
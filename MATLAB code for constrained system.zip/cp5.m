function [F] = cp5(x)
% Evaluate the tridiagonal exponential function 
% x0=(1.5,1.5,...)
n = length(x);
%F = zeros(n,1);
h=1/(n+1);
i=2:(n-1);
F(1)=x(1)-exp(cos(h*(x(1)+x(2))));
F(i)=x(i)-exp(cos(h.*(x(i-1)+x(i)+x(i+1))));
F(n)=x(n)-exp(cos(h*(x(n-1)+x(n))));
F=F(:);
% Projection P=max(x,0)
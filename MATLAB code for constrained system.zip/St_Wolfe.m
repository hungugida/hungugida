function [alpha, x, f, grad, fail, nsteps] = St_Wolfe(x0,d,op)
c1 = 0.0001;
c2 = 0.86;
% c1=delta=0.00001;, c2=sigma=0.001
f0=test_functions(x0,op);      
grad0=test_functions(x0,op,1);       
g0 = grad0'*d;
if g0 >= 0
  error('g0 must be negative, not a descent direction')
end
old = 0; fold = f0; gold = g0;
new = 1;
nexpand = max([10 -round(log2(norm(d)))]);
for k = 1:nexpand
   xnew = x0 + new*d;
   fnew=test_functions(xnew,op);      
   gradnew=test_functions(xnew,op,1);
   gnew = gradnew'*d;
   if fnew > f0 + c1*new*g0 || ((fnew >= fold) && k > 1)   %
      [alpha, x, f, grad, fail, nsteps] = zoom1(old, new, ...
          fold, fnew, gold, gnew, f0, g0, x0, d,op, c1, c2);
      return
   end
   if (gnew) <= c2*g0  
      alpha = new; x = xnew; f = fnew; grad = gradnew; fail = 0; nsteps = k;
      return
   end
   if gnew >= 0     
      [alpha, x, f, grad, fail, nsteps] = zoom1(new, old, ... 
          fnew, fold, gnew, gold, f0, g0, x0, d,op, c1, c2);
      return
   end
   old = new;       
   fold = fnew;
   gold = gnew;
   new = 2*new;     
end 
alpha = new; 
x = xnew; 
f = fnew; 
grad = gradnew; 
fail = -1;
nsteps = 0;  
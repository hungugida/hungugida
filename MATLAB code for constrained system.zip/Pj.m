function [P]=Pj(y,l,u)
P=max(l,min(y,u));
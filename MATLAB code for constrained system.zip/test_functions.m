function f=test_functions(x,fn,index)
%This function return the value or the gradient of the choosen function at
%x according to the index; it return the value at x if index is 0 or the gradient at x if index is 1
%The default is the value of the choosen function at x.
%We can choose every function by it's number
%1 for Extended White & Holst function, 2 for Extended Rosenbrock function, 3 for Extended Freudenstein 
%& Roth function, 4 for Extended Beale function, 5 for Perturbed Quadratic function 
%6 for Raydan 1 function, 7 for Extended Tridiagonal 1 function,
%8 for Diagonal 4 function, 9 for Extended Himmelblau function, 10 for Extended Powell function
%11 for FLETCHCR function (CUTE), 12 for QUARTC function (CUTE), 13 for CUBE function (CUTE).
%14 for Extended DENSCHNB function (CUTE).
n=length(x);
if nargin <3
index=0;   
end
switch fn
case 1      %Extended White & Holst function (-1.2 1 ...) ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+100*(x(2*j)-x(2*j-1)^3)^2+(1-x(2*j-1))^2;
            end
elseif index==1
            for j=1:n/2
            h(2*j-1)=-600*(x(2*j)-x(2*j-1)^3)*x(2*j-1)^2-2+2*x(2*j-1);
            h(2*j)=200*x(2*j)-200*(x(2*j-1))^3;    
            end
            f=h';
else
    error('Index must be a boolean')
end
case 2         %Extended Rosenbrock function (-1.2 1 ...) ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+100*(x(2*j)-x(2*j-1)^2)^2+(1-x(2*j-1))^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=-400*(x(2*j)-x(2*j-1)^2)*x(2*j-1)-2+2*x(2*j-1);
            h(2*j)=200*x(2*j)-200*(x(2*j-1))^2;    
            end
            f=h';
else
    error('Index must be a boolean')
end
case 3    %Extended Freudenstein & Roth function(.5 -2,...)ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+(-13+x(2*j-1)+((5-x(2*j))*x(2*j)-2)*x(2*j))^2+(-29+x(2*j-1)+((x(2*j)+1)*x(2*j)-14)*x(2*j))^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=2*(-13+x(2*j-1)+((5-x(2*j))*x(2*j)-2)*x(2*j))+2*(-29+x(2*j-1)+((x(2*j)+1)*x(2*j)-14)*x(2*j));
            h(2*j)=2*(-13+x(2*j-1)+((5-x(2*j))*x(2*j)-2)*x(2*j))*(10*x(2*j)-3*x(2*j)^2-2)+2*(-29+x(2*j-1)+((x(2*j)+1)*x(2*j)-14)*x(2*j))*(2*x(2*j)+3*x(2*j)^2-14);    
            end
            f=h';
else
    error('Index must be a boolean')
end
case 4          %Extended Beale function (1 .8 1 .8 ...) ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+(1.5-x(2*j-1)*(1-x(2*j)))^2+(2.25-x(2*j-1)*(1-x(2*j)^2))^2+(2.625-x(2*j-1)*(1-x(2*j)^3))^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=-2*(1.5-x(2*j-1)*(1-x(2*j)))*(1-x(2*j))-2*(2.25-x(2*j-1)*(1-x(2*j)^2))*(1-x(2*j)^2)-2*(2.625-x(2*j-1)*(1-x(2*j)^3))*(1-x(2*j)^3);
            h(2*j)=2*(1.5-x(2*j-1)*(1-x(2*j)))*(x(2*j-1))+2*(2.25-x(2*j-1)*(1-x(2*j)^2))*(2*x(2*j-1)*x(2*j))+2*(2.625-x(2*j-1)*(1-x(2*j)^3))*(3*x(2*j-1)*x(2*j)^2); 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 5     %Extended Wood, (-3 -1 -3 -1)
if index ==0
            f=0;
            f=100*(x(1)^2-x(2))^2+(x(1)-1)^2+90*(x(3)^2-x(4))^2+(1-x(3))^2+10.1*((x(2)-1)^2+(x(4)-1)^2)+19.8*(x(2)-1)*(x(4)-1);
elseif index ==1
            h(1)=400*x(1)*(x(1)^2-x(2))+2*(x(1)-1);
            h(2)=-200*(x(1)^2-x(2))+2*10.1*(x(2)-1)+19.8*(x(4)-1);
            h(3)=360*x(3)*(x(3)^2-x(4))-2*(1-x(3)); 
            h(4)=-180*(x(3)^2-x(4))+2*10.1*(x(4)-1)+19.8*(x(2)-1);
            f=h';
else
    error('Index must be a boolean')
end
case 6    %Raydan 1 function (1 1 ...) ok
if index ==0
            f=0;
            for j=1:n
            f=f+(j/10)*(exp(x(j))-x(j));
            end
elseif index ==1
            for j=1:n
            h(j)=(j/10)*(exp(x(j))-1);    
            end
            f=h';
else
    error('Index must be a boolean')
end
case 7         %Extended Tridiagonal 1 function, (2 2 ...)ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+(x(2*j-1)+x(2*j)-3)^2+(x(2*j-1)-x(2*j)+1)^4;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=2*(x(2*j-1)+x(2*j)-3)+4*(x(2*j-1)-x(2*j)+1)^3;
            h(2*j)=2*(x(2*j-1)+x(2*j)-3)-4*(x(2*j-1)-x(2*j)+1)^3; 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 8         %Diagonal 4 function, (1 1 ...)
if index ==0
            f=0;
            for j=1:n/2
            f=f+(1/2)*((x(2*j-1)^2)+(100*x(2*j)^2));
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=x(2*j-1);
            h(2*j)=100*x(2*j); 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 9          %Extended Himmelblau function, (1 1 ...) ok 
if index ==0
            f=0;
            for j=1:n/2
            f=f+(x(2*j-1)^2+x(2*j)-11)^2+(x(2*j-1)+x(2*j)^2-7)^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=2*(x(2*j-1)^2+x(2*j)-11)*(2*x(2*j-1))+2*(x(2*j-1)+x(2*j)^2-7);
            h(2*j)=2*(x(2*j-1)^2+x(2*j)-11)+2*(x(2*j-1)+x(2*j)^2-7)*(2*x(2*j)); 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 10          %%%%%%Extended Powell function, (0 0 ...)not
if index ==0
            f=0;
            for i=1:n/2
            f=f+(-3*x(2*i-1)-2*x(2*i)+2+x(2*i-1)^3+x(2*i)^2);
            end
elseif index ==1
            for i=1:n/2
            h(2*i-1)=(-3+3*x(2*i-1)^2);
            h(2*i)=(-2+2*x(2*i));
            end
            f=h';
else
    error('Index must be a boolean')
end
case 11          %FLETCHCR function (CUTE), (0 0 ...)not 
if index ==0
            f=0;
            for j=1:n-1
            f=f+100*(x(j+1)-x(j)+1-x(j)^2)^2;
            end
elseif index ==1
            h(1)=200*(x(2)-x(1)+1-x(1)^2)*(-1-2*(x(1)));
            for j=2:n-1
            h(j)=200*(x(j)-x(j-1)+1-x(j-1)^2)+200*(x(j+1)-x(j)+1-x(j)^2)*(-1-2*x(j)); 
            end
            h(n)=200*(x(n)-x(n-1)+1-x(n-1)^2);
            f=h';
else
    error('Index must be a boolean')
end
case 12     %Extended Powell 
if index ==0
            f=0;
            for i=1:n/4
            f=f+(x(4*i-3)+10*x(4*i-2))^2+5*(x(4*i-1)-x(4*i))^2+(x(4*i-2)-2*x(4*i-1))^4+10*(x(4*i-3)-x(4*i))^4;
            end
elseif index ==1
            for i=1:n/4
            h(4*i-3)=2*(x(4*i-3)+10*x(4*i-2))+40*(x(4*i-3)-x(4*i))^3;
            h(4*i-2)=20*(x(4*i-3)+10*x(4*i-2))+4*(x(4*i-2)-2*x(4*i-1))^3;
            h(4*i-1)=10*(x(4*i-1)-x(4*i))-8*(x(4*i-2)-2*x(4*i-1))^3; 
            h(4*i)=-10*(x(4*i-1)-x(4*i))-40*(x(4*i-3)-x(4*i))^3;
            end
            f=h';
else
    error('Index must be a boolean')
end
case 13         %NONSCOMP function (CUTE), (3 3 3 ...) 
if index ==0
            s=0;
            for j=2:n
            s=s+4*(x(j)-x(j-1)^2)^2;
            end
            f=(x(1)-1)^2+s;
elseif index ==1
            h(1)=2*(x(1)-1)-8*(x(2)-x(1)^2)*(2*x(1));
            for j=2:n-1
            h(j)=8*(x(j)-x(j-1)^2)-8*(x(j+1)-x(j)^2)*(2*x(j)); 
            end
            h(n)=8*(x(n)-x(n-1)^2);
            f=h';
else
    error('Index must be a boolean')
end
case 14         %Extended DENSCHNB function (CUTE), (1 1 ...)ok 
if index ==0
            f=0;
            for i=1:n/2
            f=f+(x(2*i-1)-2)^2+(x(2*i-1)-2)^2*x(2*i)^2+(x(2*i)+1)^2;
            end
elseif index ==1
            for i=1:n/2
            h(2*i-1)=2*(x(2*i-1)-2)+2*(x(2*i-1)-2)*(x(2*i)^2); 
            h(2*i)=2*(x(2*i-1)-2)^2*x(2*i)+2*(x(2*i)+1);
            end
            f=h';
else
    error('Index must be a boolean')
end
case 15        %Extended quadratic penalty QP1, (1 1 ...) not                
if index ==0
            f=0;s=0;t=0;
            for j=1:n
                s=s+(x(j)^2-0.5);
            end
            for j=1:n-1
                t=t+(x(j)^2-2)^2;
            end
            f=t+s^2;
elseif index ==1
            s=0;
            for j=1:n
                s=s+(x(j)^2-0.5);
            end
            for i=1:n-1
            h(i)=4*x(i)*(x(i)^2-2)+2*s*2*x(i);
            end
            h(n)=2*s*2*x(n);
            f=h';
else
    error('Index must be a boolean')
end
case 16        %Extended Penalty, (1 2 3 ...)                 50
if index ==0
            f=0;s=0;t=0;
            for j=1:n
                s=s+(x(j)^2-0.25);
            end
            for j=1:n-1
                t=t+(x(j)-1)^2;
            end
            f=t+s^2;
elseif index ==1
            s=0;
            for j=1:n
                s=s+(x(j)^2-0.25);
            end
            for i=1:n-1
            h(i)=2*(x(i)-1)+2*s*2*x(i);
            end
            h(n)=2*s*2*x(n);
            f=h';
else
    error('Index must be a boolean')
end
case 17           %Hager function, (1 1 ...)
if index ==0  
            f=0;
            for i=1:n
            f=f+(exp(x(i))-sqrt(i)*x(i));
            end
elseif index ==1
            for i=1:n
            h(i)=(exp(x(i))-sqrt(i));    
            end
            f=h';
else
    error('Index must be a boolean')
end
case 18           %BIGGSB1 function (CUTE),(0 0 ..)not
if index ==0  
            f=0;s=0;
            for i=1:n-1
            s=s+(x(i+1)-x(i))^2;
            end
            f=(x(1)-1)^2+s+(x(n)-1)^2;
elseif index ==1
            h(1)=2*(x(1)-1)-2*(x(2)-x(1));
            for i=2:n-1
            h(i)=-2*(x(i)-x(i-1))-2*(x(i+1)-x(i));
            end
            h(n)=2*(x(n)-x(n-1))-2*(1-x(n));
            f=h';
else
    error('Index must be a boolean')
end
case 19          %Extended Maratos function, (1.1 0.1 ...) ok
if index ==0
            f=0;
            for j=1:n/2
            f=f+x(2*j-1)+100*(x(2*j-1)^2+x(2*j)^2-1)^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=1+200*(x(2*j-1)^2+x(2*j)^2-1)*2*x(2*j-1);
            h(2*j)=200*(x(2*j-1)^2+x(2*j)^2-1)*2*x(2*j); 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 20          %Six hump function (1 1) not
if index ==0
            f=(4-2.1*x(1)^2+(x(1)^4)/3)*x(1)^2+x(1)*x(2)+(-4+4*x(2)^2)*x(2)^2;
elseif index ==1
            h(1)=8*x(1)-4*2.1*x(1)^3+2*x(1)^5+x(2);
            h(2)=x(1)-8*x(2)+16*x(2)^3; 
            f=h';
else
    error('Index must be a boolean')
end
case 21          %Three hump function, (-5 5) ok 
if index ==0
            f=2*x(1)^2-1.05*x(1)^4+((x(1)^6)/6)+x(1)*x(2)+x(2)^2;
elseif index ==1
            h(1)=4*x(1)-4*1.05*x(1)^3+x(1)^5-x(2);
            h(2)=-x(1)+2*x(2); 
            f=h';
else
    error('Index must be a boolean')
end
case 22          %Booth function, (-10,10), ok  
if index ==0
            f=(x(1)+2*x(2)-7)^2+(2*x(1)+x(2)-5)^2;
elseif index ==1
            h(1)=2*(x(1)+2*x(2)-7)+4*(2*x(1)+x(2)-5);
            h(2)=4*(x(1)+2*x(2)-7)+2*(2*x(1)+x(2)-5); 
            f=h';
else
    error('Index must be a boolean')
end
case 23          %Trecanni function , (-5 5) ok
if index ==0
            f=x(1)^4+4*x(1)^3+4*x(1)^2+x(2)^2;
elseif index ==1
            h(1)=4*x(1)^3+12*x(1)^2+8*x(1);
            h(2)=2*x(2); 
            f=h';
else
    error('Index must be a boolean')
end
case 24          %Zettl function , (-10 10) ok
if index ==0
            f=(x(1)^2+x(2)^2-2*x(1))^2+0.25*x(1);
elseif index ==1
            h(1)=2*(x(1)^2+x(2)^2-2*x(1))*(2*x(1)-2)+0.25;
            h(2)=2*(x(1)^2+x(2)^2-2*x(1))*2*x(2); 
            f=h';
else
    error('Index must be a boolean')
end
case 25          %Shallow function, (-2 -2 ...) 
if index ==0
            f=0;
            for j=1:n/2
            f=f+(x(2*j-1)^2-x(2*j))^2+(1-x(2*j-1))^2;
            end
elseif index ==1
            for j=1:n/2
            h(2*j-1)=2*(x(2*j-1)^2-x(2*j))*2*x(2*j-1)-2*(1-x(2*j-1));
            h(2*j)=-2*(x(2*j-1)^2-x(2*j)); 
            end
            f=h';
else
    error('Index must be a boolean')
end
case 26          %%%%Generalized Quartic function, (1 1 ...) 
if index ==0
            f=0;
            for i=1:n-1
            f=f+x(i)^2+(x(i+1)+x(i)^2)^2;
            end
elseif index ==1
            h(1)=2*x(1)+2*(x(2)+x(1)^2)*2*x(1);
            for i=2:n-1
            h(i)=2*(x(i)+x(i-1)^2)+2*(x(i+1)+x(i)^2)*2*x(i); 
            end
            h(n)=2*(x(n)+x(n-1)^2);
            f=h';
else
    error('Index must be a boolean')
end
case 27    %Quadratic QF2 function (.5 .5 ...) not
if index ==0
            f=0;s=0;
            for j=1:n
            s=s+j*(x(j)^2-1)^2;
            end
            f=(1/2)*s-x(n);
elseif index ==1
            for j=1:n-1
            h(j)=2*j*x(j)*(x(j)^2-1);    
            end
            h(n)=2*n*x(n)*(x(n)^2-1)-1;
            f=h';
else
    error('Index must be a boolean')
end
case 28          %Leon function
if index ==0
            f=100*(x(2)-x(1)^3)^2+(x(1)-1.0)^2;
elseif index ==1
            h(1)=200*(x(2)-x(1)^3)*(-3*x(1)^2)+2*(x(1)-1.0);
            h(2)=200*(x(2)-x(1)^3); 
            f=h';
else
    error('Index must be a boolean')
end
case 29        %Generlized Tridiagonal 1 function (2 2 ...)ok
if index ==0
            f=0;
            for i=1:n-1
            f=f+(x(i)+x(i+1)-3)^2+(x(i)-x(i+1)+1)^4;
            end
elseif index ==1
            h(1)=2*(x(1)+x(2)-3)+4*(x(1)-x(2)+1)^3;
            for i=2:n-1
            h(i)=2*(x(i-1)+x(i)-3)-4*(x(i-1)-x(i)+1)^3+2*(x(i)+x(i+1)-3)+4*(x(i)-x(i+1)+1)^3;    
            end
            h(n)=2*(x(n-1)+x(n)-3)-4*(x(n-1)-x(n)+1)^3;
            f=h';
else
    error('Index must be a boolean')
end
case 30         %Generlized Tridiagonal 2, (1 1 ...)
if index ==0
            f=0;
            for i=1:n-1
            f=f+(x(i)*x(i+1)-1)^2+0.1*(x(i)+1)*(x(i+1)+1);
            end
elseif index ==1
            h(1)=2*x(2)*(x(1)*x(2)-1)+0.1*x(2)+0.1;
            for i=2:n-1
            h(i)=2*x(i-1)*(x(i-1)*x(i)-1)+0.1*x(i-1)+0.1+2*x(i+1)*(x(i)*x(i+1)-1)+0.1*x(i+1)+0.1;    
            end
            h(n)=2*x(n-1)*(x(n-1)*x(n)-1)+0.1*x(n-1)+0.1;
            f=h';
else
    error('Index must be a boolean')
end
case 31         %POWER function (1,1,...,1)
if index ==0
            f=0;
            for i=1:n
            f=f+(i*x(i))^2;
            end
elseif index ==1
            for i=1:n
            h(i)=2*i^2*x(i); 
            %h(2*i)=2*x(2*i-1)*(x(2*i-1)*x(2*i)-50000);
            end
            f=h';
else
    error('Index must be a boolean')
end
case 32    %Quadratic QF1, (1 1 ...)
if index ==0
            s=0;
            for j=1:n
            s=s+j*(x(j)^2);
            end
            f=(1/2)*s-x(n);
elseif index ==1
            for j=1:n-1
            h(j)=j*x(j);    
            end
            h(n)=n*x(n)-1;
            f=h';
else
    error('Index must be a boolean')
end
case 33        %Extended quadratic penalty QP2, (1 1 ...) not                
if index ==0
            f=0;s=0;t=0;
            for j=1:n
                s=s+(x(j)^2-100);
            end
            for j=1:n-1
                t=t+(x(j)^2-sin(x(j)))^2;
            end
            f=t+s^2;
elseif index ==1
            s=0;
            for j=1:n
                s=s+(x(j)^2-100);
            end
            for i=1:n-1
            h(i)=2*(x(i)^2-sin(x(i)))*(2*x(i)-cos(x(i)))+2*s*2*x(i);
            end
            h(n)=2*s*2*x(n);
            f=h';
else
    error('Index must be a boolean')
end
case 34        %Extended quadratic penalty QP1, (1 1 ...)                 
if index ==0
            f=0;s=0;t=0;
            for j=1:n
                s=s+(x(j)^2-0.5);
            end
            for j=1:n-1
                t=t+(x(j)^2-2)^2;
            end
            f=t+s^2;
elseif index ==1
            s=0;
            for j=1:n
                s=s+(x(j)^2-0.5);
            end
            for i=1:n-1
            h(i)=2*(x(i)^2-2)*(2*x(i))+2*s*2*x(i);
            end
            h(n)=2*s*2*x(n);
            f=h';
else
    error('Index must be a boolean')
end
case 35          %Quartic function (10 10 10 10) ok
if index ==0
            f=x(1)^4+x(1)^3+x(1)^2+10*x(2)^4+x(2)^3+10*x(2)^2+100*x(3)^4+x(3)^3+100*x(3)^2+1000*x(4)^4+x(4)^3+1000*x(4)^2;
elseif index ==1
            h(1)=4*x(1)^3+3*x(1)^2+2*x(1);
            h(2)=40*x(2)^3+3*x(2)^2+20*x(2);
            h(3)=400*x(3)^3+3*x(3)^2+200*x(3);
            h(4)=4000*x(4)^3+3*x(4)^2+2000*x(4);
            f=h';
else
    error('Index must be a boolean')
end
case 36          %Matyas function
if index ==0
            f=0.26*(x(1)^2+x(2)^2)-0.48*x(1)*x(2);
elseif index ==1
            h(1)=2*0.26*x(1)-0.48*x(2);
            h(2)=2*0.26*x(2)-0.48*x(1); 
            f=h';
else
    error('Index must be a boolean')
end
case 37          % colville function
if index ==0
            f=100*(x(1)^2-x(2))^2+(x(1)-1)^2+(x(3)-1)^2+90*(x(3)^2-x(4))^2+...
10.1*((x(2)-1)^2+(x(4)-1)^2)+19.8*(x(2)-1)*(x(4)-1);
elseif index ==1
            h(1)=400*(x(1)^2-x(2))*x(1)+2*(x(1)-1);
            h(2)=-200*(x(1)^2-x(2))+2*10.1*(x(2)-1)+19.8*(x(4)-1);
            h(3)=2*(x(3)-1)+4*90*x(3)*(x(3)^2-x(4));
            h(4)=-2*90*(x(3)^2-x(4))+2*10.1*(x(4)-1)+19.8*(x(2)-1);
            f=h';
else
    error('Index must be a boolean')
end
case 38          %Dixon and Price function
if index ==0
            f=0;s1 = 0;
            for i = 2:n;
            s1 = s1+i*(2*x(i)^2-x(i-1))^2;    
            end
            f = s1+(x(1)-1)^2;
elseif index ==1
            h(1)=2*(x(1)-1)-4*(2*x(2)^2-x(1));
            for i=2:n-1
            h(i)=8*i*x(i)*(2*x(i)^2-x(i-1))-2*(i+1)*(2*x(i+1)^2-x(i));
            end
            h(n)=8*n*x(n)*(2*x(n)^2-x(n-1));
            f=h';
else
    error('Index must be a boolean')
end
case 39          %Sphere function
if index ==0
            f = 0;
           for i = 1:n
           f = f+x(i)^2; 
           end
elseif index ==1
            for i=1:n
            h(i)=2*x(i);
            end
            f=h';
else
    error('Index must be a boolean')
end
case 40          %Sum Squares function
if index ==0
            f = 0;
           for i = 1:n
           f = f+i*x(i)^2; 
           end
elseif index ==1
            for i=1:n
            h(i)=2*i*x(i);
            end
            f=h';
else
    error('Index must be a boolean')
end
case 41     %Powell 
if index ==0
            f=0;
            f=(x(1)+10*x(2))^2+5*(x(3)-x(4))^2+(x(2)-2*x(3))^4+10*(x(1)-x(4))^4;
elseif index ==1
            h(1)=2*(x(1)+10*x(2))+40*(x(1)-x(4))^3;
            h(2)=20*(x(1)+10*x(2))+4*(x(2)-2*x(3))^3;
            h(3)=10*(x(3)-x(4))-8*(x(2)-2*x(3))^3; 
            h(4)=-10*(x(3)-x(4))-40*(x(1)-x(4))^3;
            f=h';
else
    error('Index must be a boolean')
end
case 42     %Extended Wood 
if index ==0
            f=0;
            f=100*(x(1)^2-x(2))^2+(x(1)-1)^2+90*(x(3)^2-x(4))^2+(1-x(3))^2+10.1*((x(2)-1)^2+(x(4)-1)^2)+19.8*(x(2)-1)*(x(4)-1);
elseif index ==1
            h(1)=400*x(1)*(x(1)^2-x(2))+2*(x(1)-1);
            h(2)=-200*(x(1)^2-x(2))+2*10.1*(x(2)-1)+19.8*(x(4)-1);
            h(3)=360*x(3)*(x(3)^2-x(4))-2*(1-x(3)); 
            h(4)=-180*(x(3)^2-x(4))+2*10.1*(x(4)-1)+19.8*(x(2)-1);
            f=h';
else
    error('Index must be a boolean')
end
case 43     %Test
if index ==0
            f=0;
            f=(x(1)-4)^4+(x(2)-3)^2+4*(x(3)+5)^4;
elseif index ==1
            h(1)=4*(x(1)-4)^3;
            h(2)=2*(x(2)-3);
            h(3)=16*(x(3)+5)^3; 
            f=h';
else
    error('Index must be a boolean')
end
end